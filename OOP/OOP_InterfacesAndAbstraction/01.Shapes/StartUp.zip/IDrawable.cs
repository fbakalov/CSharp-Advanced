﻿
namespace _01.Shapes;

public interface IDrawable
{
    public void Draw();
}
