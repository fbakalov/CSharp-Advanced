﻿
namespace FoodShortage.Models.Interfaces
{
    public interface INameble
    {
        string Name { get; }
    }
}
