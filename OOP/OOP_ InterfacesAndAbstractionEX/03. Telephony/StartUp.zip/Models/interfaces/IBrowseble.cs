﻿namespace Telephony;

public interface IBrowseble
{
    public string Browse(string url);
}